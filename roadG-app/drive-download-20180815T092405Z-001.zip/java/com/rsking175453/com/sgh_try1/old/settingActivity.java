package com.rsking175453.com.sgh_try1.old;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.rsking175453.com.sgh_try1.R;

public class settingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
    }
}
